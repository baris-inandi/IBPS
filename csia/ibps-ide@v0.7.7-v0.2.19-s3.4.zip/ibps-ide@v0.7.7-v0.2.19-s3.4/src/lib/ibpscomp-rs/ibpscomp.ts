import init, { ibps_to_py, ibpscomp_rs_version } from "ibpscomp-rs";

const ibpsToPy = async (code: string): Promise<string> => {
    const output = (msg: string) => {
        console.groupCollapsed("Intermediate Representation");
        console.log(msg);
        console.groupEnd();
    };
    await init();
    const out = ibps_to_py(code);
    output(out);
    return out;
};

export const getCompilerVersion = async () => {
    await init();
    return ibpscomp_rs_version();
};

export default ibpsToPy;
