declare module "react-resize-panel";
