class String(str):
    @property
    def length(self):
        return len(self)
