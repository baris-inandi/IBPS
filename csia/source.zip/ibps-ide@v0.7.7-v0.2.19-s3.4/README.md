# IBPS

IBPS is a scripting language based on the pseudocode specification of the International Baccalaureate Diploma Program Computer Science course.

## Building the IBPS IDE

1. Download and install `yarn` following the instructions at [https://yarnpkg.com/](https://yarnpkg.com/)
2. Run `yarn install` in the root directory to install all dependencies.
3. Either:
    1. Run `yarn dev` to start a development server at `localhost:8080`.
    2. or run `yarn build` to create an optimized build for production in the build/ directory. Run `yarn preview` to run the production build at `localhost:8080`.

## Contents

This repository contains the following contents:

### `ibpscomp-rs`: The Rust-based IBPS Compiler

The Rust-based implementation of the IBPS compiler.

This Rust crate includes a library and a binary. The library is used to compile IBPS code to an intermediate representation. The binary compiles the IBPS code in the specified path and prints the intermediate representation to stdout.

### The IBPS IDE

The online IBPS IDE. This is a Preact application written in Typescript that allows users to write and execute IBPS code in their browser.

The IDE ships `ibpscomp-rs` compiled using `wasm-pack`. The IDE uses WebAssembly to compile and run the IBPS code.
