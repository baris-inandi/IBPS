export const CONSOLE_WELCOME_MSG = `
Welcome to the IBPS IDE.
Press the run button to run a script.
The output will be displayed here.
`;

export const WELCOME_CODE = 'output "Hello, World!"';
