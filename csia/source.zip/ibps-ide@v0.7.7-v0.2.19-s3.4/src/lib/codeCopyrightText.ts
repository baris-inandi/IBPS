export const codeCopyrightText = `
#######################################
# Feel free to play around, experiment,
# and explore the features showcased
# in this example.
#######################################
`;
