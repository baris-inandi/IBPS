const DEFAULT_CODE = `loop I from 1 to 20
    loop J from 1 to I
        output "#", end=""
    end loop
    output
end loop
`;
export default DEFAULT_CODE;
