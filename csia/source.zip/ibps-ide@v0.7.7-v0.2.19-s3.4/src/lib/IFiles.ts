export default interface IFiles {
    active: string;
    allFiles: Record<string, string>;
}
