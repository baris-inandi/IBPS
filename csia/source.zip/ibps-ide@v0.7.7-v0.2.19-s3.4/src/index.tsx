import { ContainerNode, render } from "preact";
import { Route, Switch } from "wouter-preact";
import NotFound from "./components/ErrorNotFound";
import IBPSProvider from "./components/IBPSProvider";
import Ide from "./components/Ide/Ide";

const root = document.getElementById("root") as ContainerNode;

const node = (
    <IBPSProvider>
        <Switch>
            <Route path="/" component={Ide} />
            <Route>
                <NotFound />
            </Route>
        </Switch>
    </IBPSProvider>
);

render(node, root);
